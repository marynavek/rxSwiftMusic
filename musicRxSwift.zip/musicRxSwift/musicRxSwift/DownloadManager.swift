//
//  DownloadManager.swift
//  musicRxSwift
//
//  Created by Maryna Veksler on 2/13/20.
//  Copyright © 2020 Maryna Veksler. All rights reserved.
//

import Foundation
import UIKit
import Alamofire
import RxSwift
import RxCocoa

class DownloadManger {
    
    let bag = DisposeBag()
    
    func download(track: Track) -> URL?{
        var savedPath : URL?
        guard let url = URL(string: track.preview!) else { print ("No preview url for \(track.title)")
            return nil
        }
        URLSession.shared.downloadTask(with: url) { (data, response, error) in
            guard let fileUrl = data else { return }
            do {
                let documentUrl = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
                let newUrl = documentUrl.appendingPathComponent(fileUrl.lastPathComponent)
                try FileManager.default.moveItem(at: fileUrl, to: newUrl)
                savedPath = newUrl
                print(savedPath)
            } catch {
                print("file error \(error)")
            }
        }.resume()
        
        return savedPath
    }
    
}
    
    
