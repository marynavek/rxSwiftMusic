//
//  ViewModel.swift
//  musicRxSwift
//
//  Created by Maryna Veksler on 2/11/20.
//  Copyright © 2020 Maryna Veksler. All rights reserved.
//

import Foundation
import UIKit
import RxSwift
import RxCocoa
import IHProgressHUD

class ViewModel {
    
    let tracksArray : BehaviorRelay<[Track]> = BehaviorRelay(value: [])
    
    var arrTracks = [Track]()
    var error : Error?
    
    var disposeBag = DisposeBag()
    
    func callAPIVM(request: URLRequest){
        IHProgressHUD.show()
        let disposable = APIHandler().fetchData(request: request).subscribe(onNext: { (data) in

            var arrTracks = [Track]()
            
            do{
                let model = try JSONSerialization.jsonObject(with: data!, options: []) as! [String : Any]
                print(model)
                let dict = model["data"] as! NSArray

                var arrDict = [[String : Any]]()
                var tracksArr = [Track]()
                for item in dict {
                    arrDict.append(item as! [String : Any])
                }
                for item in arrDict {
                    let oneTrack = Track(artist: item["artist"] as! [String : Any], album: item["album"] as! [String : Any], title: item["title"] as! String, preview: item["preview"] as! String, info: nil, donwloaded: false)
                    tracksArr.append(oneTrack)
                }
                for track in tracksArr {
                    let info = Info(artistName: track.artist!["name"] as! String, coverImg: track.album!["cover_small"] as! String)
                    let final = Track(artist: track.artist, album: track.album, title: track.title, preview: track.preview, info: info, donwloaded: track.donwloaded)
                    arrTracks.append(final)
                }
                
                self.tracksArray.accept(arrTracks)
                self.arrTracks = arrTracks
                IHProgressHUD.dismiss()
                print(self.tracksArray)
            } catch {
                self.error = error
            }
        }, onError: { (error) in
            self.error = error
        }, onCompleted: {
        }) {
            print("disposed")
        }
        disposable.disposed(by: disposeBag)
    }
}

