//
//  ValidatePhoneNumber.swift
//  musicRxSwift
//
//  Created by Maryna Veksler on 2/13/20.
//  Copyright © 2020 Maryna Veksler. All rights reserved.
//

import Foundation


//extension String {
//    func validatePhone(_ phoneNumber : String) -> Bool{
//        var validate = Bool()
//        if phoneNumber.count < 10 {
//            validate = false
//        } else {
//            if phoneNumber.rangeOfCharacter(from: CharacterSet.letters) != nil {
//                validate = false
//            }
//            
//            if phoneNumber.count == 10 {
//                for (index, ch) in phoneNumber.enumerated() {
//                    
//                }
//            }
//        }
//        return validate
//    }
//
//}
//Description: Returns true if the input string is a valid phone number
//Example: phoneNumber = (888) 888-8888, return value = true
//Example: phoneNumber = 8888888888, return value = true
//Example: phoneNumber = 8, return value = false
//Example: phoneNumber = a number with *


