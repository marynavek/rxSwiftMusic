//
//  APIHandlet.swift
//  musicRxSwift
//
//  Created by Maryna Veksler on 2/11/20.
//  Copyright © 2020 Maryna Veksler. All rights reserved.
//

import Foundation
import UIKit
import RxSwift
import RxCocoa
import Alamofire


class APIHandler {
    
    
    func fetchData(request: URLRequest) -> Observable<Data?>{
        Observable<Data?>.create { observer in
            URLSession.shared.dataTask(with: request) { (data, response, error) in
                observer.onNext(data)
                if error != nil {
                    observer.onError(error!)
                }
                observer.onCompleted()
            }.resume()
            let disposable = Disposables.create()
            return disposable
        }
        
    }
    
}

extension URL {
    static func constructURL(artistName: String) -> URL? {
        var components = URLComponents()
        components.scheme = "https"
        components.host = "deezerdevs-deezer.p.rapidapi.com"
        components.path = "/search"
        
        let params : [String: String] = [
            "q" : artistName
        ]
        
        components.setQueryItems(param: params)
        return components.url
    }
}

extension URLComponents {
    
    mutating func setQueryItems(param: [String: String]) {
        self.queryItems = param.map({ URLQueryItem(name: $0.key, value: $0.value) })
    }
    
}







