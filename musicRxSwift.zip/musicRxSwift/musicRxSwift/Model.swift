//
//  Model.swift
//  musicRxSwift
//
//  Created by Maryna Veksler on 2/11/20.
//  Copyright © 2020 Maryna Veksler. All rights reserved.
//

import Foundation

struct Track  {
    var artist : [String : Any]?
    var album : [String : Any]?
    var title : String?
    var preview : String?
    
    var info : Info?
    
    var donwloaded : Bool?

}

struct Info {
    var artistName : String?
    var coverImg : String?
}
