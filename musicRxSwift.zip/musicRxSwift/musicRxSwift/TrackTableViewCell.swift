//
//  TrackTableViewCell.swift
//  musicRxSwift
//
//  Created by Maryna Veksler on 2/11/20.
//  Copyright © 2020 Maryna Veksler. All rights reserved.
//

import UIKit
import RxCocoa
import RxSwift

protocol CellProtocol {
    func buttonPressed(track: Track)
}

class TrackTableViewCell: UITableViewCell {

    @IBOutlet weak var artistName: UILabel!
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var trackName: UILabel!
    @IBOutlet weak var downloadPlayBtn: UIButton!
    
    var track : Track?
  
    var delegate : CellProtocol?
    let disposeBag = DisposeBag()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        imgView.sizeToFit()
        
    }

    func setImage(url: String?) {
        guard let imgURL = URL(string: url!) else {
            print("No image")
            return
        }
        DispatchQueue.global().async {
            guard let imageData = try? Data(contentsOf: imgURL) else {
                print("error happened")
                return
            }
            let image = UIImage(data: imageData)
            DispatchQueue.main.async {
                self.imgView.image = image
            }
        }
    }
    
//    func updateBtn(status: Bool?){
//        if status == false {
//            downloadPlayBtn.setImage(UIImage(named: "download"), for: .normal)
//            
//        } else {
//            downloadPlayBtn.setImage(UIImage(named: "play"), for: .normal)
//        }
//        downloadPlayBtn.imageView?.sizeToFit()
//    }
    
    
    
//    func bindTap(){
//        downloadPlayBtn.rx.tap.subscribe(onNext: { (observer) in
//            self.delegate?.buttonPressed(track: self.track!)
//        }, onError: { error in
//            print("error happened \(error)")
//        }, onCompleted: {
//            print("")
//        }) .disposed(by: disposeBag)
//    }

}
