//
//  ViewController.swift
//  musicRxSwift
//
//  Created by Maryna Veksler on 2/11/20.
//  Copyright © 2020 Maryna Veksler. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
import Alamofire
import AVFoundation
import AVKit
import IHProgressHUD

class ViewController: UIViewController{
    

    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tblView: UITableView!
    
    
    let avPlayer = AVPlayerViewController()
    let viewModel = ViewModel()
    let disposeBag = DisposeBag()

    
    
    
    let headers = [
        "x-rapidapi-host": "deezerdevs-deezer.p.rapidapi.com",
        "x-rapidapi-key": "89a050ef48mshef62aafe75f2937p1f70a5jsn2bde4060ac1b"
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        DispatchQueue.main.async {
            self.setUpBinding()
        }
    }
    
    @objc func buttonPressed(sender: UIButton) {
        let track = viewModel.arrTracks[sender.tag]
        playTrack(track: track)
      }
      
    func playTrack(track : Track){
        if !avPlayer.isBeingPresented {
            avPlayer.player?.pause()
            present(avPlayer, animated: true, completion: nil)
            let player = AVPlayer(url: URL(string: track.preview!)!)
            player.rate = 1.0
            avPlayer.player = player
            player.play()
        }
    }
    
      
    func search(_ searchItem: String){
        print("search for \(searchItem)")
        guard let url = URL.constructURL(artistName: searchItem) else { return }
        
        let request = NSMutableURLRequest(url: url, cachePolicy: .useProtocolCachePolicy, timeoutInterval: 10.0)
        request.httpMethod = "GET"
        request.allHTTPHeaderFields = headers
        viewModel.callAPIVM(request: request as URLRequest)
        
    }

    func setUpBinding() {
        searchBar.rx.searchButtonClicked.subscribe(onNext: { [weak self](_) in
            guard let strongSelf = self else { return }
            if strongSelf.searchBar.isFirstResponder {strongSelf.searchBar.resignFirstResponder()}
            let searchItem = strongSelf.searchBar.text ?? ""
            strongSelf.search(searchItem)
            
            }).disposed(by: disposeBag)
        
        
        
        viewModel.tracksArray.bind(to: self.tblView.rx.items) {
            (tableView, row, element) in
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! TrackTableViewCell
            cell.track = element
            cell.artistName.text = element.info?.artistName
            cell.trackName.text = element.title
            cell.setImage(url: element.info?.coverImg)
            cell.downloadPlayBtn.tag = row
            cell.downloadPlayBtn.addTarget(self, action: #selector(self.buttonPressed), for: .touchUpInside)
            return cell
        }.disposed(by: disposeBag)
    }
    
}


